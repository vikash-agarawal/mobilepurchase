/**
 * 
 */
/**
 * @author SCHOUHAN
 *
 */
package com.cg.mra.beans;