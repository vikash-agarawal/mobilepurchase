package com.cg.mra.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Before;
import org.junit.jupiter.api.Test;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.dao.IAccountDao;
import com.cg.mra.exception.InvalidAccountNumber;

class Testing {
	@Before
	public void runEveryTimeBeforeTest() {
		System.out.println("test run before create account");
	}

	@Test
	void test() throws InvalidAccountNumber {
		Account a=new Account("Prepaid", "Vaishali", (double)200);
		IAccountDao dao=new AccountDaoImpl();
		assertEquals(a, dao.getAccountDetails("9010210131"));
	}
}
