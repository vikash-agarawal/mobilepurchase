package com.cg.mra.exception;

public class InvalidAccountNumber extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidAccountNumber(String string) {
		super(string);
		// TODO Auto-generated constructor stub
	}
	
}
