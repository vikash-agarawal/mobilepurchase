package com.cg.capgemini.service;

import java.util.regex.Pattern;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.dao.IAccountDao;
import com.cg.mra.exception.InvalidAccountNumber;

public class AccountServiceImpl implements IAccountService {
IAccountDao dao=new AccountDaoImpl();
	@Override
	public Account getAccountDetails(String mobileNo) throws InvalidAccountNumber {
		if(Pattern.matches("[0-9]{10}", mobileNo))
		{
			return (dao.getAccountDetails(mobileNo));
		}
		else
		{
			throw new InvalidAccountNumber("mobile no . is not in correct format");
		}
	}

	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) throws InvalidAccountNumber {
		if(Pattern.matches("[0-9]{10}", mobileNo))
		{
			return (dao.rechargeAccount(mobileNo, rechargeAmount));
		}
		else
		{
			throw new InvalidAccountNumber("mobile no . is not in correct format");
		}
	}

}
